// Contador Javascript
const inputSuma = document.querySelector('#sum');
const buttonSuma = document.querySelector('#suma');

// Función suma
function suma (event) {
    let resultadoSuma = inputSuma.value;
    resultadoSuma++;
    inputSuma.value = resultadoSuma;
}

//Listener para ejecutar la función "suma" con el evento "click"
buttonSuma.addEventListener("click", suma);
